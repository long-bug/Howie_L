from django.contrib import admin
from rbac import models

# Register your models here.
# admin.site.register(models.Menu)
# admin.site.register(models.User)


# class PermissionAdmin(admin.ModelAdmin):
#     list_display = ['id', 'url', 'title', 'name', 'menu']
#     list_editable = ['url', 'title', 'name', 'menu']
#     ordering = ('id',)
#
#
# admin.site.register(models.Permission, PermissionAdmin)
#
# admin.site.register(models.Role)
